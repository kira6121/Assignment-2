library(readr)
library(arules)
library(arulesViz)

df <- read.csv( file = "C:/Users/Asus/Desktop/Data Mining Assignment/Data Mining Assignment 2/Data1.csv" , header = FALSE , col.names = c("Receipt_Number","Quantity","Product_ID"))


#Change Product ID to Product Name
df$Product_ID <- as.factor(df$Product_ID)
levels(df$Product_ID) <- c("Chocolate Cake","Lemon Cake","Casino Cake","Opera Cake", "Strawberry Cake", "Truffle Cake", "Chocolate Eclair", "Coffee Eclair", "Vanilla Eclair", "Napolean Cake", "Almond Tart", "Apple Pie", "Apple Tart","Apricot Tart", "Berry Tart", "Blackberry Tart", "Blueberry Tart", "Chocolate Tart", "Cherry Tart", "Lemon Tart", "Pecan Tart", "Ganache Cookie", "Gongolais Cookie", "Raspberry Cookie", "Lemon Cookie", "Chocolate Meringue", "Vanilla Meringue", "Marzipan Cookie", "Tuile Cookie", "Walnut Cookie", "Almond Croissant", "Apple Croissant", "Apricot Croissant", "Cheese Croissant", "Chocolate Croissant", "Apricot Danish", "Apple Danish", "Almond Twist", "Almond Bear Claw", "Blueberry Danish", "Lemonade", "Raspberry Lemonade", "Orange Juice", "Green Tea", "Bottled Water", "Hot Coffee", "Chocolate Coffee", "Vanilla Frappucino", "Cherry Soda", "Single Espresso")

# Change Column Name
colnames(df)[which(names(df) == "Product_ID")] <- "Product_Name" 


# Arules
appriori_df <- as(split(df$Product_Name, df$Receipt_Number), "transactions")

rules<-apriori(appriori_df, control=list(verbose=F),parameter=list(minlen=2,supp=0.02,conf=0.99,target='rules'))

rules.sorted <- sort(rules,by="lift") 

inspect(rules.sorted) 


# Find redundent rule
subset.matrix <- is.subset(x=rules.sorted, y=rules.sorted)

subset.matrix[lower.tri(subset.matrix, diag=T)] <- NA

redundant <- colSums(subset.matrix, na.rm=T) >= 1

which(redundant)


# Remove redundent rule
rules.pruned <- rules.sorted[!redundant]
inspect(rules.pruned)


# Visualization
plot(rules.sorted) 
plot(rules.sorted, method="grouped")
plot(rules.sorted, method="graph")
